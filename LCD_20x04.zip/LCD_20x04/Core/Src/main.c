/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "i2c-lcd.h"


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint16_t real;
uint16_t error;
uint16_t modified;

int encoder[13];
uint16_t combined_bits;
uint16_t placeholder;

uint16_t XMB_Setpoint = 0b0000001000000;
uint16_t error_offset = 0;

uint8_t current_state_EN;
uint8_t previous_state_EN;

uint8_t current_state_Reset;
uint8_t previous_state_Reset;

uint8_t current_state_Clear;
uint8_t previous_state_Clear;

uint8_t current_state_Inc;
uint8_t previous_state_Inc;

uint8_t current_state_Dec;
uint8_t previous_state_Dec;

char testing;
int counter;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */



  lcd_init();
  lcd_set_labels(); 	// Setting up the LCD labels

  current_state_EN = HAL_GPIO_ReadPin(GPIOC, Enable_Button_Pin);
  previous_state_EN = current_state_EN;

  current_state_Reset = HAL_GPIO_ReadPin(GPIOC, Reset_Button_Pin);
  previous_state_Reset = current_state_Reset;

  current_state_Clear = HAL_GPIO_ReadPin(GPIOA, Clear_Button_Pin);
  previous_state_Clear = current_state_Clear;

  current_state_Inc = HAL_GPIO_ReadPin(GPIOH, Inc_Button_Pin);
  previous_state_Inc = current_state_Inc;

  current_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);
  previous_state_Dec = current_state_Dec;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {

	  /* Bit 0 to Bit 3 */
	 encoder[0] = HAL_GPIO_ReadPin(GPIOC, Bit_0_Input_Pin);       	// Reading Bit 0
	 combined_bits |= (encoder[0] & 0x01) << (0);            	  	// combing all bits together

	 HAL_GPIO_WritePin(GPIOB,Bit_0__Output_Pin, encoder[0]); 		// Writing input to Bit 0

	 encoder[1] = HAL_GPIO_ReadPin(GPIOC, Bit_1_Input_Pin); 		// Reading bit 1
	 combined_bits |= (encoder[1] & 0x01) << (1);            	  	// combing all bits together

	 HAL_GPIO_WritePin(GPIOB,Bit_1_Output_Pin, encoder[1]); 		// Assigning Bit 1 value of input

	encoder[2] = HAL_GPIO_ReadPin(GPIOC, Bit_2_Input_Pin);			// Reading bit 2
	combined_bits |= (encoder[2] & 0x01) << (2);            	  	// combing all bits together

	HAL_GPIO_WritePin(GPIOB,Bit_2_Output_Pin, encoder[2]);			// Assigning Bit 2 value of input

	encoder[3] = HAL_GPIO_ReadPin(GPIOC,Bit_3_Input_Pin);			// Reading bit 3
	combined_bits |= (encoder[3] & 0x01) << (3);            	  	// combing all bits together

	HAL_GPIO_WritePin(GPIOB,Bit_3_Output_Pin, encoder[3]);



	 /* Bit 4 to Bit 7 */
	 encoder[4] = HAL_GPIO_ReadPin(GPIOA, Bit_4_Input_Pin);      // Reading bit 4
	 combined_bits |= (encoder[4] & 0x01) << (4);

	 HAL_GPIO_WritePin(GPIOB,Bit_4_Output_Pin, encoder[4]);

	 encoder[5] = HAL_GPIO_ReadPin(GPIOA, Bit_5_Input_Pin);      // Reading bit 5
	 combined_bits |= (encoder[5] & 0x01) << (5);

	 HAL_GPIO_WritePin(GPIOB,Bit_5_Output_Pin, encoder[5]);

	 encoder[6] = HAL_GPIO_ReadPin(GPIOA, Bit_6_Input_Pin);      // Reading bit 6
	 combined_bits |= (encoder[6] & 0x01) << (6);

	 HAL_GPIO_WritePin(GPIOA,Bit_6_Output_Pin, encoder[6]);

	 encoder[7] = HAL_GPIO_ReadPin(GPIOA, Bit_7_Input_Pin);       // Reading bit 7
	 combined_bits |= (encoder[7] & 0x01) << (7);

	 HAL_GPIO_WritePin(GPIOC,Bit_7_Output_Pin, encoder[7]);
//
//	 /* Bit 8 to Bit 11 */
	 encoder[8] = HAL_GPIO_ReadPin(GPIOA, Bit_8_Input_Pin);       // Reading bit 8
	 combined_bits |= (encoder[8] & 0x01) << (8);

	 HAL_GPIO_WritePin(GPIOC,Bit_8_Output_Pin, encoder[8]);


	 encoder[9] = HAL_GPIO_ReadPin(GPIOC, Bit_9_Input_Pin);      // Reading bit 9
	 combined_bits |= (encoder[9] & 0x01) << (9);

	 HAL_GPIO_WritePin(GPIOC,Bit_9_Output_Pin, encoder[9]);

	 encoder[10] = HAL_GPIO_ReadPin(GPIOC, Bit_10_Input_Pin);     // Reading bit 10
	 combined_bits |= (encoder[10] & 0x01) << (10);

	 HAL_GPIO_WritePin(GPIOC,Bit_10_Output_Pin, encoder[10]);

	 encoder[11] = HAL_GPIO_ReadPin(GPIOB, Bit_11_Input_Pin);     // Reading bit 11
	 combined_bits |= (encoder[11] & 0x01) << (11);

	 HAL_GPIO_WritePin(GPIOA,Bit_11_Output_Pin, encoder[11]);

	 /* Bit 12 */
	 encoder[12] = HAL_GPIO_ReadPin(GPIOB, Bit_12_Input_Pin);     // Reading bit 12
	 combined_bits |= (encoder[12] & 0x01) << (12);

	HAL_GPIO_WritePin(GPIOB,Bit_12_Output_Pin, encoder[12]);


	lcd_send_real(combined_bits);

	/******************************** Checking Buttons **************************************/

	// Button toggle for Enable
	// Enable button - Temporary PC0
	current_state_EN = HAL_GPIO_ReadPin(GPIOC, Enable_Button_Pin);

	if (current_state_EN != previous_state_EN){		// If enable button is pressed
			   HAL_Delay(50); 	//debounce time
			   current_state_EN = HAL_GPIO_ReadPin(GPIOC, Enable_Button_Pin);

			   if(current_state_EN == 1){
				   /*  If Enable is high, do the following:
				   * 	1. Start a timer for the enable, if not button presses and timeout exit the if statement
				   * 	2. Check for Reset Button
				   * 	3. Check for Clear Button
				   * 	4. Check for Increment Button
				   * 	5. Check for Decrement Button
				   *
				   * */
				   // counter = 1346260 --> approximately t = 60 seconds
				   counter = 0;
				   while(counter <= 1346260){

					   	// Reset
					   current_state_Reset = HAL_GPIO_ReadPin(GPIOC, Reset_Button_Pin);
					   current_state_Clear = HAL_GPIO_ReadPin(GPIOA, Clear_Button_Pin);
					   current_state_Inc = HAL_GPIO_ReadPin(GPIOH, Inc_Button_Pin);
					   current_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);

					   if (current_state_Reset!= previous_state_Reset){
						   HAL_Delay(50); 	//debounce time
						   current_state_Reset = HAL_GPIO_ReadPin(GPIOC, Reset_Button_Pin);

						   if(current_state_Reset == 1){
							   placeholder = combined_bits;
							   error = placeholder - XMB_Setpoint;
							   counter = 1346260;		// to exit the enable loop
							   // Updating modified
							   	modified = combined_bits - error;
							   lcd_send_error(error);
							   lcd_send_modified(modified);
						   }
					   }
					   //Clear
					   else if(current_state_Clear != previous_state_Clear){
						   HAL_Delay(50); 	//debounce time
						   current_state_Clear = HAL_GPIO_ReadPin(GPIOA, Clear_Button_Pin);

						   if(current_state_Clear == 1){
							   error = 0;
							   counter = 1346260;		// to exit the enable loop
							   // Updating modified
							   	modified = combined_bits - error;
							   lcd_send_error(error);
							   lcd_send_modified(modified);
						   }
					   }
					   // Decrement
					   else if(current_state_Dec != previous_state_Dec){
						   HAL_Delay(50); 	//debounce time
						   current_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);

						   if(current_state_Dec == 1){
							   error -=1;
							   // Updating modified
							   	modified = combined_bits - error;
							   lcd_send_error(error);
							   lcd_send_modified(modified);
						   }

					   }
					   // Increment
					   else if(current_state_Inc != previous_state_Inc){
						   HAL_Delay(50); 	//debounce time
						   current_state_Inc = HAL_GPIO_ReadPin(GPIOH, Inc_Button_Pin);

						   if(current_state_Inc == 1){
							   error +=1;
							   // Updating modified
							   	modified = combined_bits - error;
							   lcd_send_error(error);
							   lcd_send_modified(modified);
						   }

					   }


					   counter+=1; 		// For the timeout of enable

				   }

			   }
	}


	// real = 0b1111111111111;

//
//
//	  HAL_Delay(1000);
	  //real = rand();
	 // error = rand();
	  //modified = rand();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	// Updating modified
		modified = combined_bits - error;

	// Updating Previous enable button state
	previous_state_EN == current_state_EN;
	previous_state_Reset == current_state_Reset;
	previous_state_Clear == current_state_Clear;
	previous_state_Inc == current_state_Inc;
	 previous_state_Dec == current_state_Dec;


	  lcd_send_error(error);
	  lcd_send_modified(modified);


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_5;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00000708;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Bit_0__Output_Pin|Bit_1_Output_Pin|Bit_2_Output_Pin|Bit_3_Output_Pin
                          |Bit_4_Output_Pin|Bit_5_Output_Pin|Bit_12_Output_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, Bit_7_Output_Pin|Bit_8_Output_Pin|Bit_9_Output_Pin|Bit_10_Output_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Bit_11_Output_Pin|Bit_6_Output_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : Inc_Button_Pin */
  GPIO_InitStruct.Pin = Inc_Button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(Inc_Button_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_0_Input_Pin Bit_1_Input_Pin Bit_2_Input_Pin Bit_3_Input_Pin
                           Bit_9_Input_Pin Bit_10_Input_Pin */
  GPIO_InitStruct.Pin = Bit_0_Input_Pin|Bit_1_Input_Pin|Bit_2_Input_Pin|Bit_3_Input_Pin
                          |Bit_9_Input_Pin|Bit_10_Input_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_4_Input_Pin Bit_6_Input_Pin Bit_7_Input_Pin Bit_8_Input_Pin
                           Bit_5_Input_Pin */
  GPIO_InitStruct.Pin = Bit_4_Input_Pin|Bit_6_Input_Pin|Bit_7_Input_Pin|Bit_8_Input_Pin
                          |Bit_5_Input_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_11_Input_Pin Bit_12_Input_Pin */
  GPIO_InitStruct.Pin = Bit_11_Input_Pin|Bit_12_Input_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_0__Output_Pin Bit_1_Output_Pin Bit_2_Output_Pin Bit_3_Output_Pin
                           Bit_4_Output_Pin Bit_5_Output_Pin Bit_12_Output_Pin */
  GPIO_InitStruct.Pin = Bit_0__Output_Pin|Bit_1_Output_Pin|Bit_2_Output_Pin|Bit_3_Output_Pin
                          |Bit_4_Output_Pin|Bit_5_Output_Pin|Bit_12_Output_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_7_Output_Pin Bit_8_Output_Pin Bit_9_Output_Pin Bit_10_Output_Pin */
  GPIO_InitStruct.Pin = Bit_7_Output_Pin|Bit_8_Output_Pin|Bit_9_Output_Pin|Bit_10_Output_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_11_Output_Pin Bit_6_Output_Pin */
  GPIO_InitStruct.Pin = Bit_11_Output_Pin|Bit_6_Output_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : Clear_Button_Pin */
  GPIO_InitStruct.Pin = Clear_Button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(Clear_Button_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Enable_Button_Pin Dec_Button_Pin Reset_Button_Pin */
  GPIO_InitStruct.Pin = Enable_Button_Pin|Dec_Button_Pin|Reset_Button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

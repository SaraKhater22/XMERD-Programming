/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "i2c-lcd.h"


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

IWDG_HandleTypeDef hiwdg;

TIM_HandleTypeDef htim6;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM6_Init(void);
static void MX_IWDG_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint32_t Flash_Address = 0x08080000;
uint16_t real;
uint16_t error;
uint16_t modified;
uint16_t dummy_error;
int modified_array[13];

int encoder[13];
uint16_t combined_bits_Gray;
uint16_t combined_bits_Binary;
uint16_t placeholder;

uint16_t XMB_Setpoint = 0b0000001000000;
uint16_t error_offset = 0;

uint8_t current_state_EN =0;
uint8_t previous_state_EN = 0;

uint8_t current_state_Reset =0;
uint8_t previous_state_Reset = 0;



uint8_t current_state_Clear =0;
uint8_t previous_state_Clear = 0;

uint8_t current_state_Inc =0;
uint8_t previous_state_Inc = 0;

uint8_t current_state_Dec = 0;
uint8_t previous_state_Dec = 0;



uint16_t Enable_Timeout = 60;			// In seconds
uint16_t exit_flag = 0;

/* Fail Safe System Testing Variables */
uint16_t prev_error_inc;
uint16_t prev_error_dec;


int counter;

uint16_t grayToBinary(uint16_t num)
  {
      uint16_t mask;
      for (mask = num >> 1; mask != 0; mask = mask >> 1)
      {
          num = num ^ mask;
      }
      return num;
  }

uint16_t binaryToGray(uint16_t num)
{
    return num ^ (num >> 1);
}

void save_data(uint32_t Address,uint32_t data){

    HAL_FLASH_Unlock();
	FLASH_EraseInitTypeDef EraseInitStruct;
	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.PageAddress = Address;
	EraseInitStruct.NbPages = 1;

	uint32_t PageError;
	if (HAL_FLASHEx_Erase(&EraseInitStruct, &PageError) != HAL_OK)		//Erase the Page Before a Write Operation
			return HAL_ERROR;

	HAL_Delay(50);
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,Address,(uint64_t)data);
	HAL_Delay(50);
	HAL_FLASH_Lock();


}

uint32_t read_data(uint32_t Address){

	__IO uint32_t read_data = *(__IO uint32_t *)Address;
	return (uint32_t)read_data;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
uint16_t timer_val;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM6_Init();
  MX_IWDG_Init();
  /* USER CODE BEGIN 2 */



  lcd_init();
  lcd_set_labels(); 	// Setting up the LCD labels

//  timer_val = __HAL_TIM_GET_COUNTER(&htim6);	//Store it
//  lcd_send_Timer( timer_val*timer_period);		//Send to LCD


  //current_state_Inc = HAL_GPIO_ReadPin(GPIOA, Inc_Button_Pin);
  //previous_state_Inc = current_state_Inc;


  error = read_data(Flash_Address);	//Fetch the error value from memory at the start of the program
  HAL_GPIO_WritePin(GPIOA, FFS_Pin,1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {



	  combined_bits_Gray =0;
	  combined_bits_Binary =0;

	 HAL_IWDG_Refresh(&hiwdg);


	  /* Bit 0 to Bit 3 */
	 encoder[0] = HAL_GPIO_ReadPin(GPIOB, Bit_0_Input_Pin);       	// Reading Bit 0
	 combined_bits_Gray |= (encoder[0] & 0x01) << (0);            	  	// combing all bits together

	 encoder[1] = HAL_GPIO_ReadPin(GPIOB, Bit_1_Input_Pin); 		// Reading bit 1
	 combined_bits_Gray |= (encoder[1] & 0x01) << (1);            	  	// combing all bits together

	encoder[2] = HAL_GPIO_ReadPin(GPIOC, Bit_2_Input_Pin);			// Reading bit 2
	combined_bits_Gray |= (encoder[2] & 0x01) << (2);            	  	// combing all bits together

	encoder[3] = HAL_GPIO_ReadPin(GPIOC,Bit_3_Input_Pin);			// Reading bit 3
	combined_bits_Gray |= (encoder[3] & 0x01) << (3);            	  	// combing all bits together

	 /* Bit 4 to Bit 7 */
	 encoder[4] = HAL_GPIO_ReadPin(GPIOA, Bit_4_Input_Pin);      // Reading bit 4
	 combined_bits_Gray |= (encoder[4] & 0x01) << (4);

	 encoder[5] = HAL_GPIO_ReadPin(GPIOA, Bit_5_Input_Pin);      // Reading bit 5
	 combined_bits_Gray |= (encoder[5] & 0x01) << (5);

	 encoder[6] = HAL_GPIO_ReadPin(GPIOA, Bit_6_Input_Pin);      // Reading bit 6
	 combined_bits_Gray |= (encoder[6] & 0x01) << (6);

	 encoder[7] = HAL_GPIO_ReadPin(GPIOA, Bit_7_Input_Pin);       // Reading bit 7
	 combined_bits_Gray |= (encoder[7] & 0x01) << (7);

	 /* Bit 8 to Bit 11 */
	 encoder[8] = HAL_GPIO_ReadPin(GPIOA, Bit_8_Input_Pin);       // Reading bit 8
	 combined_bits_Gray |= (encoder[8] & 0x01) << (8);

	 encoder[9] = HAL_GPIO_ReadPin(GPIOC, Bit_9_Input_Pin);      // Reading bit 9
	 combined_bits_Gray |= (encoder[9] & 0x01) << (9);

	 encoder[10] = HAL_GPIO_ReadPin(GPIOC, Bit_10_Input_Pin);     // Reading bit 10
	 combined_bits_Gray |= (encoder[10] & 0x01) << (10);

	 encoder[11] = HAL_GPIO_ReadPin(GPIOC, Bit_11_Input_Pin);     // Reading bit 11
	 combined_bits_Gray |= (encoder[11] & 0x01) << (11);

	 /* Bit 12 */
	 encoder[12] = HAL_GPIO_ReadPin(GPIOC, Bit_12_Input_Pin);     // Reading bit 12
	 //combined_bits_Gray |= (encoder[12] & 0x01) << (12);

	combined_bits_Binary = grayToBinary(combined_bits_Gray);
	lcd_send_real(combined_bits_Binary);
	lcd_send_error(error);

	modified = grayToBinary(modified);

    lcd_send_modified(modified);

	/******************************** Checking Buttons **************************************/

	// Button toggle for Enable
	// Enable button - Temporary PC0
    current_state_EN = HAL_GPIO_ReadPin(GPIOA, Enable_Button_Pin);

   // current_state_EN = 1;

	if (current_state_EN != previous_state_EN){		// If enable button is pressed
			   HAL_Delay(50); 	//debounce time

			   if(current_state_EN == 1){

				   /* ******************************************************************
				    * If Enable is high, do the following:
				   * 	1. Start a timer for the enable, if not button presses and timeout exit the if statement
				   * 	2. Check for Reset Button
				   * 	3. Check for Clear Button
				   * 	4. Check for Increment Button
				   * 	5. Check for Decrement Button
				   *
				   *
				   *	counter = 1346260 --> approximately t = 60 seconds
				   * *****************************************************************/
				   //Starting timer
				  HAL_TIM_Base_Start(&htim6);
               	  timer_val = __HAL_TIM_GET_COUNTER(&htim6);

               	   exit_flag = 0;
				   while(!exit_flag){
					   HAL_IWDG_Refresh(&hiwdg);

					   if (!(timer_val *0.03125 <= Enable_Timeout)){
						   exit_flag = 1;		//To exit flag

					   }

					   timer_val = __HAL_TIM_GET_COUNTER(&htim6);
					   lcd_send_Timer( timer_val*0.03125);
					   	// Reset
					   current_state_Reset = HAL_GPIO_ReadPin(GPIOA, Reset_Button_Pin);
					   current_state_Clear = HAL_GPIO_ReadPin(GPIOA, Clear_Button_Pin);
					   current_state_Inc = HAL_GPIO_ReadPin(GPIOA, Inc_Button_Pin);
					   current_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);

					   if (current_state_Reset!= previous_state_Reset){
						   HAL_Delay(50); 	//Debounce time
//						 //  HAL_IWDG_Refresh(&hiwdg);
						   current_state_Reset = HAL_GPIO_ReadPin(GPIOA, Reset_Button_Pin);

						   if(current_state_Reset == 1){
							  // placeholder = combined_bits_Binary;
							   error = combined_bits_Binary - XMB_Setpoint;
//
							   save_data(Flash_Address,error); 	//Store error updates in Flash memory

							   // Updating modified
							   	modified = XMB_Setpoint ;
							   	lcd_send_error(error);
							   	lcd_send_modified(modified);


							   	previous_state_Inc = HAL_GPIO_ReadPin(GPIOA, Inc_Button_Pin);
							   	previous_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);

							   exit_flag = 1;			// To exit flag
							   //timer_val = 2000;
//
//
//							   	/* Temporary Code for testing*/
//							   	modified = 10000;		// Comment code out after testing
//
//								   /* Fail Safe System test */
								 if (modified == XMB_Setpoint){

									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,0);	// Turn on LED if modified is incorrect
								 }
								 else{
									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,1);
								 }
//
//								// HAL_IWDG_Refresh(&hiwdg);

						   }
					   }
					   //Clear
					   if(current_state_Clear != previous_state_Clear){
						   HAL_Delay(50); 	//debounce time
//						  // HAL_IWDG_Refresh(&hiwdg);
						   current_state_Clear = HAL_GPIO_ReadPin(GPIOA, Clear_Button_Pin);

						   if(current_state_Clear == 1){
							   error = 0;
							   placeholder = combined_bits_Binary;

							   save_data(Flash_Address,error); 	//Store error updates in Flash memory

							   // Updating modified
							   modified = combined_bits_Binary - error;
							   lcd_send_error(error);
							   lcd_send_modified(modified);
							   previous_state_Dec = current_state_Dec;
							   previous_state_Inc = current_state_Inc;
							   exit_flag = 1;		//To exit flag

//								/* Temporary Code for testing*/
//								//error = 5; 		// Comment code out after testing

//								   /* Fail Safe Sysetem test */
								 if (error != 0){

									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,0);	// Turn on LED if error is incorrect
								 }
								 else{
									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,1);
								 }
//
//								// HAL_IWDG_Refresh(&hiwdg);
							  // lcd_send_error(error);
							   //lcd_send_modified(modified);
						   }
					   }
					   // Decrement
					   if(current_state_Dec != previous_state_Dec){
						   HAL_Delay(50); 	//debounce time
						 //  HAL_IWDG_Refresh(&hiwdg);


						   current_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);

						   if(current_state_Dec == 1){

							   prev_error_dec = error;

							  if (error > 0){
								   error -=1;		// Comment out during Fail safe test
								  lcd_send_error(error);
								   save_data(Flash_Address,error); 	//Store error updates in Flash memory
							   }
							   //else if (error == 0){
								 //  HAL_GPIO_WritePin(GPIOA, FFS_Pin,0);
							   //}

							   if (error == prev_error_dec){

									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,0);	// Turn on LED if error is incorrect
								 }
								 else{
									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,1);
								 }
							   // Updating modified
							   	modified = combined_bits_Binary - error;
							   	lcd_send_modified(modified);


							   //	HAL_IWDG_Refresh(&hiwdg);
							  // lcd_send_error(error);
							  // lcd_send_modified(modified);

							   HAL_Delay(50);
							   previous_state_Dec = HAL_GPIO_ReadPin(GPIOC, Dec_Button_Pin);
						   }

					   }
//					   // Increment
					   if(current_state_Inc != previous_state_Inc){
					   HAL_Delay(50); 	//debounce time
//						  // HAL_IWDG_Refresh(&hiwdg);
						   current_state_Inc = HAL_GPIO_ReadPin(GPIOA, Inc_Button_Pin);
//
						   if(current_state_Inc == 1){

							   prev_error_inc = error;

							  if (error < 17777){
								   error +=1; // comment this out during fail safe test
								   lcd_send_error(error);
								   save_data(Flash_Address,error); 	//Store error updates in Flash memory
							  }
							  // else if (error >= 17777){
								//   HAL_GPIO_WritePin(GPIOA, FFS_Pin,0);
							   //}

//
							   if (error == prev_error_inc){

									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,0);	// Turn on LED if error is incorrect
								 }
								 else{
									 HAL_GPIO_WritePin(GPIOA, FFS_Pin,1);
								 }

							   // Updating modified
							   	modified = combined_bits_Binary - error;
							   	lcd_send_modified(modified);
//
//							   //	HAL_IWDG_Refresh(&hiwdg);
							  // lcd_send_error(error);
							   //lcd_send_modified(modified);


							   HAL_Delay(50);
							   previous_state_Inc = HAL_GPIO_ReadPin(GPIOA, Inc_Button_Pin);
						   }

					   }

				   }

			   }
	}

	   HAL_TIM_Base_Stop(&htim6);		// Stop the timer
	   MX_TIM6_Init();					// Re-initalize the timer
	   timer_val = __HAL_TIM_GET_COUNTER(&htim6);	//Store timer value
	   lcd_send_Timer( timer_val*0.03125);		//Send to LCD




	// real = 0b1111111111111;

//
//
//	  HAL_Delay(1000);
	  //real = rand();
	 // error = rand();
	  //modified = rand();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

//	// Updating modified
    modified = combined_bits_Binary - error;

	// Updating Previous enable button state
	previous_state_EN = 0;
	previous_state_Reset = current_state_Reset;
	previous_state_Clear = current_state_Clear;
	previous_state_Inc = current_state_Inc;
	previous_state_Dec = current_state_Dec;

	//lcd_send_modified(modified);


	modified = binaryToGray(modified);

	for (int i = 0; i < 12; i++)		// 13 represents the size of array and the number of bits
		{
			// Check if the bit is set
			if (modified & (1 << i))
			{
				modified_array[i] = 1; // Set the bit in the array
			}
			else
			{
				modified_array[i] = 0; // Clear the bit in the array (optional)
			}
		}


	 HAL_GPIO_WritePin(GPIOA,Bit_0_Output_Pin, modified_array[0]); 			//  Writing input to Bit 0
	 HAL_GPIO_WritePin(GPIOA,Bit_1_Output_Pin, modified_array[1]); 			//  Writing input to Bit 1
	 HAL_GPIO_WritePin(GPIOC,Bit_2_Output_Pin, modified_array[2]);			//  Writing input to Bit 2
	 HAL_GPIO_WritePin(GPIOC,Bit_3_Output_Pin, modified_array[3]);			//  Writing input to Bit 3
	 HAL_GPIO_WritePin(GPIOC,Bit_4_Output_Pin, modified_array[4]);			//  Writing input to Bit 4
	 HAL_GPIO_WritePin(GPIOC,Bit_5_Output_Pin, modified_array[5]);			//  Writing input to Bit 5
	 HAL_GPIO_WritePin(GPIOB,Bit_6_Output_Pin, modified_array[6]);			//  Writing input to Bit 6
	 HAL_GPIO_WritePin(GPIOB,Bit_7_Output_Pin, modified_array[7]);			//  Writing input to Bit 7
	 HAL_GPIO_WritePin(GPIOB,Bit_8_Output_Pin, modified_array[8]);			//  Writing input to Bit 8
	 HAL_GPIO_WritePin(GPIOB,Bit_9_Output_Pin, modified_array[9]);			//  Writing input to Bit 9
	 HAL_GPIO_WritePin(GPIOB,Bit_10_Output_Pin, modified_array[10]);		//  Writing input to Bit 10
	 HAL_GPIO_WritePin(GPIOB,Bit_11_Output_Pin, modified_array[11]);		//  Writing input to Bit 11


	 modified_array[12] = encoder[12];
	 HAL_GPIO_WritePin(GPIOB,Bit_12_Output_Pin, modified_array[12]);		//  Writing input to Bit 12

	 lcd_send_error(error);



  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_5;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00000708;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */



  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief IWDG Initialization Function
  * @param None
  * @retval None
  */
static void MX_IWDG_Init(void)
{

  /* USER CODE BEGIN IWDG_Init 0 */

  /* USER CODE END IWDG_Init 0 */

  /* USER CODE BEGIN IWDG_Init 1 */

  /* USER CODE END IWDG_Init 1 */
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_256;
  hiwdg.Init.Window = 4095;
  hiwdg.Init.Reload = 2312;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IWDG_Init 2 */

  /* USER CODE END IWDG_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 65535;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 65535;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(FFS_GPIO_Port, FFS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Bit_12_Output_Pin|Bit_11_Output_Pin|Bit_10_Output_Pin|Bit_9_Output_Pin
                          |Bit_8_Output_Pin|Bit_7_Output_Pin|Bit_6_Output_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, Bit_5_Output_Pin|Bit_4_Output_Pin|Bit_3_Output_Pin|Bit_2_Output_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Bit_1_Output_Pin|Bit_0_Output_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Bit_12_Input_Pin Bit_11_Input_Pin Bit_10_Input_Pin Bit_9_Input_Pin
                           Bit_3_Input_Pin Bit_2_Input_Pin */
  GPIO_InitStruct.Pin = Bit_12_Input_Pin|Bit_11_Input_Pin|Bit_10_Input_Pin|Bit_9_Input_Pin
                          |Bit_3_Input_Pin|Bit_2_Input_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : FFS_Pin Bit_1_Output_Pin Bit_0_Output_Pin */
  GPIO_InitStruct.Pin = FFS_Pin|Bit_1_Output_Pin|Bit_0_Output_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_8_Input_Pin Bit_7_Input_Pin Bit_6_Input_Pin Bit_5_Input_Pin
                           Bit_4_Input_Pin */
  GPIO_InitStruct.Pin = Bit_8_Input_Pin|Bit_7_Input_Pin|Bit_6_Input_Pin|Bit_5_Input_Pin
                          |Bit_4_Input_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_1_Input_Pin Bit_0_Input_Pin */
  GPIO_InitStruct.Pin = Bit_1_Input_Pin|Bit_0_Input_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_12_Output_Pin Bit_11_Output_Pin Bit_10_Output_Pin Bit_9_Output_Pin
                           Bit_8_Output_Pin Bit_7_Output_Pin Bit_6_Output_Pin */
  GPIO_InitStruct.Pin = Bit_12_Output_Pin|Bit_11_Output_Pin|Bit_10_Output_Pin|Bit_9_Output_Pin
                          |Bit_8_Output_Pin|Bit_7_Output_Pin|Bit_6_Output_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Bit_5_Output_Pin Bit_4_Output_Pin Bit_3_Output_Pin Bit_2_Output_Pin */
  GPIO_InitStruct.Pin = Bit_5_Output_Pin|Bit_4_Output_Pin|Bit_3_Output_Pin|Bit_2_Output_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : Enable_Button_Pin Reset_Button_Pin Clear_Button_Pin Inc_Button_Pin */
  GPIO_InitStruct.Pin = Enable_Button_Pin|Reset_Button_Pin|Clear_Button_Pin|Inc_Button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : Dec_Button_Pin */
  GPIO_InitStruct.Pin = Dec_Button_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(Dec_Button_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

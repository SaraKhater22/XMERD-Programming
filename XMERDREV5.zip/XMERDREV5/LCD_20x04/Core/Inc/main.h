/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Bit_12_Input_Pin GPIO_PIN_0
#define Bit_12_Input_GPIO_Port GPIOC
#define Bit_11_Input_Pin GPIO_PIN_1
#define Bit_11_Input_GPIO_Port GPIOC
#define Bit_10_Input_Pin GPIO_PIN_2
#define Bit_10_Input_GPIO_Port GPIOC
#define Bit_9_Input_Pin GPIO_PIN_3
#define Bit_9_Input_GPIO_Port GPIOC
#define FFS_Pin GPIO_PIN_0
#define FFS_GPIO_Port GPIOA
#define Bit_8_Input_Pin GPIO_PIN_1
#define Bit_8_Input_GPIO_Port GPIOA
#define Bit_7_Input_Pin GPIO_PIN_2
#define Bit_7_Input_GPIO_Port GPIOA
#define Bit_6_Input_Pin GPIO_PIN_3
#define Bit_6_Input_GPIO_Port GPIOA
#define Bit_5_Input_Pin GPIO_PIN_6
#define Bit_5_Input_GPIO_Port GPIOA
#define Bit_4_Input_Pin GPIO_PIN_7
#define Bit_4_Input_GPIO_Port GPIOA
#define Bit_3_Input_Pin GPIO_PIN_4
#define Bit_3_Input_GPIO_Port GPIOC
#define Bit_2_Input_Pin GPIO_PIN_5
#define Bit_2_Input_GPIO_Port GPIOC
#define Bit_1_Input_Pin GPIO_PIN_0
#define Bit_1_Input_GPIO_Port GPIOB
#define Bit_0_Input_Pin GPIO_PIN_1
#define Bit_0_Input_GPIO_Port GPIOB
#define Bit_12_Output_Pin GPIO_PIN_2
#define Bit_12_Output_GPIO_Port GPIOB
#define Bit_11_Output_Pin GPIO_PIN_10
#define Bit_11_Output_GPIO_Port GPIOB
#define Bit_10_Output_Pin GPIO_PIN_11
#define Bit_10_Output_GPIO_Port GPIOB
#define Bit_9_Output_Pin GPIO_PIN_12
#define Bit_9_Output_GPIO_Port GPIOB
#define Bit_8_Output_Pin GPIO_PIN_13
#define Bit_8_Output_GPIO_Port GPIOB
#define Bit_7_Output_Pin GPIO_PIN_14
#define Bit_7_Output_GPIO_Port GPIOB
#define Bit_6_Output_Pin GPIO_PIN_15
#define Bit_6_Output_GPIO_Port GPIOB
#define Bit_5_Output_Pin GPIO_PIN_6
#define Bit_5_Output_GPIO_Port GPIOC
#define Bit_4_Output_Pin GPIO_PIN_7
#define Bit_4_Output_GPIO_Port GPIOC
#define Bit_3_Output_Pin GPIO_PIN_8
#define Bit_3_Output_GPIO_Port GPIOC
#define Bit_2_Output_Pin GPIO_PIN_9
#define Bit_2_Output_GPIO_Port GPIOC
#define Bit_1_Output_Pin GPIO_PIN_8
#define Bit_1_Output_GPIO_Port GPIOA
#define Bit_0_Output_Pin GPIO_PIN_9
#define Bit_0_Output_GPIO_Port GPIOA
#define Enable_Button_Pin GPIO_PIN_10
#define Enable_Button_GPIO_Port GPIOA
#define Reset_Button_Pin GPIO_PIN_11
#define Reset_Button_GPIO_Port GPIOA
#define Clear_Button_Pin GPIO_PIN_12
#define Clear_Button_GPIO_Port GPIOA
#define Inc_Button_Pin GPIO_PIN_15
#define Inc_Button_GPIO_Port GPIOA
#define Dec_Button_Pin GPIO_PIN_10
#define Dec_Button_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
